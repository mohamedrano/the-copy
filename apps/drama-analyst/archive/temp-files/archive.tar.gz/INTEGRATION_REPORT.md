# Integration Report

## Layered Architecture Overview

| Layer | Directory | Responsibilities |
|-------|-----------|------------------|
| Core | `core/` | Shared enumerations, domain types, and configuration constants used across the application. |
| Agents | `agents/` | Individual agent configurations and instructions grouped per agent, plus shared instruction templates. |
| Orchestration | `orchestration/` | Agent registry and runtime orchestration utilities (agent factory, orchestration manager). |
| Services | `services/` | External service integrations such as Gemini processing and file ingestion utilities. |
| UI | `ui/` | React components, application shell, and UI-specific iconography. |

## Dependency Flow

1. **UI ➜ Services ➜ Orchestration ➜ Agents**  
   `@ui/App` orchestrates user interactions, delegates file parsing to `@services/fileReaderService`, and invokes `@services/geminiService`, which in turn pulls agent metadata from `@agents/index` and instructions from `@agents/taskInstructions`.

2. **UI ➜ Core**  
   UI components consume `@core/constants`, `@core/enums`, and `@core/types` for shared labels, categories, and strongly typed data contracts.

3. **Agents ➜ Core**  
   Each agent configuration imports `TaskType`, `TaskCategory`, and agent typings from the shared core layer to ensure consistent typing.

4. **Orchestration ➜ Agents/Core**  
   The orchestration manager aggregates `AGENT_CONFIGS` and leverages shared types to build collaboration graphs and metadata for the runtime.

## Shared Utilities

- **Path Aliases**: Configured in `tsconfig.json` and `vite.config.ts` for `@core/*`, `@agents/*`, `@orchestration/*`, `@ui/*`, and `@services/*`.
- **Instruction Templates**: Centralized in `agents/shared/advancedModuleOutputStructure.ts` and consumed by specialized agent instructions.

## Updated Entry Points

- HTML entry loads `ui/main.tsx`.
- React root renders `@ui/App`.

## Validation Commands

- Type-check: `npx tsc --noEmit`
- Build: `npm run build`

